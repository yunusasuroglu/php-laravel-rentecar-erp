<!-- Footer Start -->
<footer class="footer mt-auto py-3 bg-white text-center">
    <div class="container">
        <span class="text-muted">
            Copyright ©
            <span id="year"></span>
            <a href="javascript:void(0);" class="text-dark fw-semibold">Safari RENTSOFT</a> </a> • All rights reserved.
        </span>
    </div>
</footer>
<!-- Footer End -->